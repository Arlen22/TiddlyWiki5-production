/*\
title: absolute/b.js
type: application/javascript
module-type: library

Absolute require test

\*/


exports.foo = function() {};
