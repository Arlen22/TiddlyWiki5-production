/*\
title: submodule/b.js
type: application/javascript
module-type: library

Relative test B

\*/

exports.foo = function () {
};

