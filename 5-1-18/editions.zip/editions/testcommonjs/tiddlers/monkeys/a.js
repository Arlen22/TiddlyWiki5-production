/*\
title: monkeys/a.js
type: application/javascript
module-type: library

Monkeys test A

\*/

require('./program').monkey = 10;


